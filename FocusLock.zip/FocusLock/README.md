# FocusLock

App Android que bloquea las apps que distraen. Para volver a usarlas hay que ganar a la "casa" en un juego (Blackjack, Cara o Cruz o Alto/Bajo). Si ganas, te llevas un rato de uso libre. Si pierdes, la próxima espera obligatoria se multiplica. El Teléfono, los SMS y WhatsApp nunca se bloquean.

## Compilar

```
.\gradlew.bat assembleDebug
```

El APK queda en `app\build\outputs\apk\debug\app-debug.apk`.

## Instalar en el móvil

**Opción A — con cable y depuración USB:**
1. En el móvil: Ajustes → Acerca del teléfono → pulsa 7 veces "Número de compilación" para activar Opciones de desarrollador.
2. Ajustes → Opciones de desarrollador → activa "Depuración USB".
3. Conecta el móvil por USB y acepta el aviso de "¿Confiar en este ordenador?".
4. Desde este proyecto:
   ```
   C:\Android\Sdk\platform-tools\adb.exe install -r app\build\outputs\apk\debug\app-debug.apk
   ```

**Opción B — sin cable:**
1. Copia `app-debug.apk` al móvil (Drive, WhatsApp Web, USB, etc.).
2. Ábrelo desde el móvil y permite "instalar apps desconocidas" para esa app de origen cuando lo pida.

## Primer uso (importante)

1. Abre **FocusLock**. La pantalla principal avisa si falta el permiso de accesibilidad — es obligatorio, sin él la app no puede detectar qué app abres.
2. Pulsa **"Activar permiso"** → te lleva a Ajustes de Accesibilidad del sistema → busca **FocusLock** en la lista → actívalo → confirma el diálogo de permisos.
3. Vuelve a FocusLock y pulsa **"Elegir apps a bloquear"** → marca las apps que quieres restringir (redes sociales, juegos, etc.). Teléfono, SMS, WhatsApp y el propio launcher no aparecen en la lista porque nunca se bloquean.
4. (Opcional) En **"Ajustes"** puedes cambiar la probabilidad de ganar, los minutos libres al ganar, el multiplicador de penalización, la penalización base/máxima y la hora de reinicio diario.

## Probar que funciona

- Abre una app que hayas marcado como bloqueada → debería aparecer la pantalla de bloqueo de FocusLock en vez de la app.
- Juega una partida:
  - Si ganas → la app marcada se desbloquea durante los minutos configurados (por defecto 10).
  - Si pierdes → no puedes reintentar hasta que pase la penalización, y la próxima penalización será mayor (multiplicador, por defecto x1.8).
- Prueba el **Blackjack**: paga 1:1 (no 3:2), el crupier pide carta en "17 blando", y los empates los gana la casa — la ventaja de la banca es intencionada pero ligera.
- Comprueba la emergencia: con la penalización activa (incluso al máximo), pulsa **"Acceso de emergencia"** desde la pantalla de bloqueo o desde el inicio → los botones de Teléfono, SMS y WhatsApp deben abrir esas apps sin restricción alguna.
- Revisa **"Historial"** para ver victorias/derrotas y la evolución de la penalización.

## Notas

- El APK está firmado con la clave de depuración (debug), pensado para instalación personal, no para publicar en Google Play.
- FocusLock no pide permisos especiales del sistema (sin superposición, sin "uso de apps", sin llamadas) — todo el bloqueo se basa en el Servicio de Accesibilidad, que el propio usuario activa y puede desactivar en cualquier momento desde Ajustes. Es una herramienta de autodisciplina, no un control parental a prueba de manipulaciones.
- Al detectar la apertura de una app bloqueada hay un pequeño margen (accesibilidad + lanzar la pantalla de bloqueo) en el que la app puede verse una fracción de segundo antes de quedar cubierta.
