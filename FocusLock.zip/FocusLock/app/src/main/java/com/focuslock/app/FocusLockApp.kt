package com.focuslock.app

import android.app.Application
import com.focuslock.app.data.HistoryDb
import com.focuslock.app.data.Prefs
import com.focuslock.app.restrict.RestrictionManager

class FocusLockApp : Application() {

    lateinit var historyDb: HistoryDb

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        historyDb = HistoryDb(this)
        RestrictionManager.init(historyDb)
    }
}
