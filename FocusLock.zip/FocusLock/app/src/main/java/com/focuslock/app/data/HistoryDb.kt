package com.focuslock.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class GameSessionRecord(
    val gameType: String,
    val won: Boolean,
    val penaltyBeforeMin: Int,
    val penaltyAfterMin: Int,
    val timestamp: Long
)

data class EventRecord(
    val type: String,
    val detail: String,
    val timestamp: Long
)

class HistoryDb(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "focuslock_history.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE game_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                game_type TEXT NOT NULL,
                won INTEGER NOT NULL,
                penalty_before INTEGER NOT NULL,
                penalty_after INTEGER NOT NULL,
                timestamp INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE event_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL,
                detail TEXT NOT NULL,
                timestamp INTEGER NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS game_sessions")
        db.execSQL("DROP TABLE IF EXISTS event_log")
        onCreate(db)
    }

    fun insertGameSession(gameType: String, won: Boolean, penaltyBeforeMin: Int, penaltyAfterMin: Int) {
        val values = ContentValues().apply {
            put("game_type", gameType)
            put("won", if (won) 1 else 0)
            put("penalty_before", penaltyBeforeMin)
            put("penalty_after", penaltyAfterMin)
            put("timestamp", System.currentTimeMillis())
        }
        writableDatabase.insert("game_sessions", null, values)
    }

    fun insertEvent(type: String, detail: String) {
        val values = ContentValues().apply {
            put("type", type)
            put("detail", detail)
            put("timestamp", System.currentTimeMillis())
        }
        writableDatabase.insert("event_log", null, values)
    }

    fun recentGameSessions(limit: Int = 30): List<GameSessionRecord> {
        val list = mutableListOf<GameSessionRecord>()
        val cursor = readableDatabase.query(
            "game_sessions", null, null, null, null, null, "id DESC", limit.toString()
        )
        cursor.use {
            while (it.moveToNext()) {
                list.add(
                    GameSessionRecord(
                        gameType = it.getString(it.getColumnIndexOrThrow("game_type")),
                        won = it.getInt(it.getColumnIndexOrThrow("won")) == 1,
                        penaltyBeforeMin = it.getInt(it.getColumnIndexOrThrow("penalty_before")),
                        penaltyAfterMin = it.getInt(it.getColumnIndexOrThrow("penalty_after")),
                        timestamp = it.getLong(it.getColumnIndexOrThrow("timestamp"))
                    )
                )
            }
        }
        return list
    }

    fun recentEvents(limit: Int = 30): List<EventRecord> {
        val list = mutableListOf<EventRecord>()
        val cursor = readableDatabase.query(
            "event_log", null, null, null, null, null, "id DESC", limit.toString()
        )
        cursor.use {
            while (it.moveToNext()) {
                list.add(
                    EventRecord(
                        type = it.getString(it.getColumnIndexOrThrow("type")),
                        detail = it.getString(it.getColumnIndexOrThrow("detail")),
                        timestamp = it.getLong(it.getColumnIndexOrThrow("timestamp"))
                    )
                )
            }
        }
        return list
    }

    fun winLossCount(): Pair<Int, Int> {
        val cursor = readableDatabase.rawQuery("SELECT won, COUNT(*) FROM game_sessions GROUP BY won", null)
        var wins = 0
        var losses = 0
        cursor.use {
            while (it.moveToNext()) {
                val won = it.getInt(0) == 1
                val count = it.getInt(1)
                if (won) wins = count else losses = count
            }
        }
        return Pair(wins, losses)
    }
}
