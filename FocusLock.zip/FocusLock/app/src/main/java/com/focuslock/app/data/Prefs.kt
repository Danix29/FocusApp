package com.focuslock.app.data

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val FILE = "focuslock_prefs"
    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        prefs = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    }

    var winProbabilityPercent: Int
        get() = prefs.getInt("win_probability_percent", 45)
        set(value) = prefs.edit().putInt("win_probability_percent", value).apply()

    var freeWindowMinutes: Int
        get() = prefs.getInt("free_window_minutes", 10)
        set(value) = prefs.edit().putInt("free_window_minutes", value).apply()

    var penaltyMultiplierPercent: Int
        get() = prefs.getInt("penalty_multiplier_percent", 180)
        set(value) = prefs.edit().putInt("penalty_multiplier_percent", value).apply()

    var basePenaltyMinutes: Int
        get() = prefs.getInt("base_penalty_minutes", 5)
        set(value) = prefs.edit().putInt("base_penalty_minutes", value).apply()

    var maxPenaltyMinutes: Int
        get() = prefs.getInt("max_penalty_minutes", 120)
        set(value) = prefs.edit().putInt("max_penalty_minutes", value).apply()

    var dailyResetHour: Int
        get() = prefs.getInt("daily_reset_hour", 4)
        set(value) = prefs.edit().putInt("daily_reset_hour", value).apply()

    var currentPenaltyMinutes: Int
        get() = prefs.getInt("current_penalty_minutes", -1).let { if (it < 0) basePenaltyMinutes else it }
        set(value) = prefs.edit().putInt("current_penalty_minutes", value).apply()

    var freeWindowEndsAt: Long
        get() = prefs.getLong("free_window_ends_at", 0L)
        set(value) = prefs.edit().putLong("free_window_ends_at", value).apply()

    var retryAvailableAt: Long
        get() = prefs.getLong("retry_available_at", 0L)
        set(value) = prefs.edit().putLong("retry_available_at", value).apply()

    var lastResetEpochDay: Long
        get() = prefs.getLong("last_reset_epoch_day", -1L)
        set(value) = prefs.edit().putLong("last_reset_epoch_day", value).apply()

    var lossStreak: Int
        get() = prefs.getInt("loss_streak", 0)
        set(value) = prefs.edit().putInt("loss_streak", value).apply()

    var blockedApps: Set<String>
        get() = prefs.getStringSet("blocked_apps", emptySet()) ?: emptySet()
        set(value) = prefs.edit().putStringSet("blocked_apps", value).apply()

    var onboardingDone: Boolean
        get() = prefs.getBoolean("onboarding_done", false)
        set(value) = prefs.edit().putBoolean("onboarding_done", value).apply()
}
