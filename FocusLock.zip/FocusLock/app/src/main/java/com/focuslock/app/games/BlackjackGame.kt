package com.focuslock.app.games

import kotlin.random.Random

data class Card(val rank: Int, val suit: String) {
    val label: String
        get() = when (rank) {
            1 -> "A"
            11 -> "J"
            12 -> "Q"
            13 -> "K"
            else -> rank.toString()
        }

    fun display(): String = "$label$suit"
}

/**
 * Blackjack con reglas inclinadas a favor de la banca: blackjack paga 1:1 (no 3:2),
 * los empates los gana la banca, el crupier pide en soft 17, y 6 mazos en baraja
 * continua impiden el conteo de cartas.
 */
class BlackjackGame(private val random: Random = Random.Default) {

    private val shoe = ArrayDeque<Card>()
    val playerHand = mutableListOf<Card>()
    val dealerHand = mutableListOf<Card>()

    var finished = false
        private set
    var playerWon = false
        private set
    var resultText = ""
        private set

    init {
        buildShoe()
        dealInitial()
    }

    private fun buildShoe() {
        shoe.clear()
        val suits = listOf("♠", "♥", "♦", "♣")
        repeat(6) {
            for (suit in suits) {
                for (rank in 1..13) {
                    shoe.add(Card(rank, suit))
                }
            }
        }
        shoe.shuffle(random)
    }

    private fun drawCard(): Card {
        if (shoe.isEmpty()) buildShoe()
        return shoe.removeFirst()
    }

    private fun dealInitial() {
        playerHand.add(drawCard()); dealerHand.add(drawCard())
        playerHand.add(drawCard()); dealerHand.add(drawCard())

        val playerBJ = handValue(playerHand) == 21
        val dealerBJ = handValue(dealerHand) == 21
        if (playerBJ || dealerBJ) {
            finished = true
            playerWon = playerBJ && !dealerBJ
            resultText = when {
                playerBJ && dealerBJ -> "Ambos tienen Blackjack. Empate: en la casa, los empates los gana la banca."
                playerBJ -> "Blackjack. Ganas (pago 1:1)."
                else -> "La banca tiene Blackjack. Pierdes."
            }
        }
    }

    fun hit() {
        if (finished) return
        playerHand.add(drawCard())
        val total = handValue(playerHand)
        if (total > 21) {
            finished = true
            playerWon = false
            resultText = "Te pasaste de 21 ($total). Pierdes."
        } else if (total == 21) {
            stand()
        }
    }

    fun stand() {
        if (finished) return
        while (true) {
            val (total, soft) = handValueDetailed(dealerHand)
            if (total < 17 || (total == 17 && soft)) {
                dealerHand.add(drawCard())
            } else {
                break
            }
        }
        finished = true
        val playerTotal = handValue(playerHand)
        val dealerTotal = handValue(dealerHand)
        playerWon = when {
            playerTotal > 21 -> false
            dealerTotal > 21 -> true
            playerTotal == dealerTotal -> false
            else -> playerTotal > dealerTotal
        }
        resultText = when {
            dealerTotal > 21 -> "La banca se pasa de 21 ($dealerTotal). Ganas."
            playerTotal == dealerTotal -> "Empate a $playerTotal. En la casa, los empates los gana la banca."
            playerTotal > dealerTotal -> "Ganas $playerTotal a $dealerTotal."
            else -> "La banca gana $dealerTotal a $playerTotal."
        }
    }

    fun handValue(hand: List<Card>): Int = handValueDetailed(hand).first

    private fun handValueDetailed(hand: List<Card>): Pair<Int, Boolean> {
        var total = 0
        var acesAsEleven = 0
        for (card in hand) {
            when {
                card.rank == 1 -> { total += 11; acesAsEleven++ }
                card.rank >= 11 -> total += 10
                else -> total += card.rank
            }
        }
        while (total > 21 && acesAsEleven > 0) {
            total -= 10
            acesAsEleven--
        }
        return Pair(total, acesAsEleven > 0)
    }
}
