package com.focuslock.app.games

import kotlin.random.Random

data class GameResult(val won: Boolean, val detail: String)

interface QuickGame {
    val id: String
    val displayName: String
    fun play(winProbability: Float, random: Random = Random.Default): GameResult
}

object CoinFlipGame : QuickGame {
    override val id = "coin_flip"
    override val displayName = "Cara o Cruz"

    override fun play(winProbability: Float, random: Random): GameResult {
        val choseCara = random.nextBoolean()
        val won = random.nextFloat() < winProbability
        val landedCara = if (won) choseCara else !choseCara
        val choiceText = if (choseCara) "cara" else "cruz"
        val landedText = if (landedCara) "cara" else "cruz"
        return GameResult(won, "Elegiste $choiceText, salió $landedText")
    }
}

object DiceGame : QuickGame {
    override val id = "dice"
    override val displayName = "Alto o Bajo (dado)"

    override fun play(winProbability: Float, random: Random): GameResult {
        val choseHigh = random.nextBoolean()
        val won = random.nextFloat() < winProbability
        val rolledHigh = if (won) choseHigh else !choseHigh
        val value = if (rolledHigh) random.nextInt(4, 7) else random.nextInt(1, 4)
        val choiceText = if (choseHigh) "Alto (4-6)" else "Bajo (1-3)"
        return GameResult(won, "Elegiste $choiceText, salió $value")
    }
}
