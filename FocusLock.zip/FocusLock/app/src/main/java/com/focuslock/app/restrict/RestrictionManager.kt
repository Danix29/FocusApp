package com.focuslock.app.restrict

import com.focuslock.app.data.HistoryDb
import com.focuslock.app.data.Prefs
import java.util.Calendar

object RestrictionManager {

    private lateinit var historyDb: HistoryDb

    fun init(db: HistoryDb) {
        historyDb = db
    }

    fun isFree(): Boolean {
        maybeDailyReset()
        return System.currentTimeMillis() < Prefs.freeWindowEndsAt
    }

    fun isAppBlocked(packageName: String): Boolean {
        if (!Prefs.blockedApps.contains(packageName)) return false
        return !isFree()
    }

    fun freeMillisRemaining(): Long =
        (Prefs.freeWindowEndsAt - System.currentTimeMillis()).coerceAtLeast(0)

    fun canPlayNow(): Boolean {
        maybeDailyReset()
        return System.currentTimeMillis() >= Prefs.retryAvailableAt
    }

    fun retryMillisRemaining(): Long =
        (Prefs.retryAvailableAt - System.currentTimeMillis()).coerceAtLeast(0)

    fun currentPenaltyMinutes(): Int {
        maybeDailyReset()
        return Prefs.currentPenaltyMinutes
    }

    fun winProbability(): Float = Prefs.winProbabilityPercent / 100f

    fun recordWin(gameType: String) {
        maybeDailyReset()
        val before = Prefs.currentPenaltyMinutes
        Prefs.freeWindowEndsAt = System.currentTimeMillis() + Prefs.freeWindowMinutes * 60_000L
        Prefs.currentPenaltyMinutes = Prefs.basePenaltyMinutes
        Prefs.retryAvailableAt = 0L
        Prefs.lossStreak = 0
        historyDb.insertGameSession(gameType, true, before, Prefs.basePenaltyMinutes)
    }

    fun recordLoss(gameType: String) {
        maybeDailyReset()
        val before = Prefs.currentPenaltyMinutes
        val multiplier = Prefs.penaltyMultiplierPercent / 100f
        val next = (before * multiplier).toInt()
            .coerceAtLeast(before + 1)
            .coerceAtMost(Prefs.maxPenaltyMinutes)
        Prefs.currentPenaltyMinutes = next
        Prefs.retryAvailableAt = System.currentTimeMillis() + next * 60_000L
        Prefs.lossStreak += 1
        historyDb.insertGameSession(gameType, false, before, next)
    }

    fun maybeDailyReset() {
        val today = todayEpochDay()
        if (Prefs.lastResetEpochDay != today && isPastResetHour()) {
            Prefs.currentPenaltyMinutes = Prefs.basePenaltyMinutes
            Prefs.retryAvailableAt = 0L
            Prefs.lossStreak = 0
            Prefs.lastResetEpochDay = today
        }
    }

    private fun isPastResetHour(): Boolean {
        val cal = Calendar.getInstance()
        return cal.get(Calendar.HOUR_OF_DAY) >= Prefs.dailyResetHour
    }

    private fun todayEpochDay(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis / 86_400_000L
    }
}
