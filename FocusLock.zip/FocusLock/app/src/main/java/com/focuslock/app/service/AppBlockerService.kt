package com.focuslock.app.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.focuslock.app.restrict.RestrictionManager
import com.focuslock.app.ui.BlockOverlayActivity

class AppBlockerService : AccessibilityService() {

    private var lastBlockedPackage: String? = null
    private var lastBlockTime: Long = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val packageName = event.packageName?.toString() ?: return

        if (SafeApps.alwaysSafePackages(this).contains(packageName)) return

        if (RestrictionManager.isAppBlocked(packageName)) {
            val now = System.currentTimeMillis()
            if (packageName == lastBlockedPackage && now - lastBlockTime < 800) return
            lastBlockedPackage = packageName
            lastBlockTime = now

            val intent = Intent(this, BlockOverlayActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            intent.putExtra(BlockOverlayActivity.EXTRA_BLOCKED_PACKAGE, packageName)
            startActivity(intent)
        }
    }

    override fun onInterrupt() {}
}
