package com.focuslock.app.service

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Telephony
import android.telecom.TelecomManager

/**
 * Centraliza qué apps nunca pueden bloquearse. Se resuelve en tiempo de
 * ejecución (no por nombre de paquete fijo) porque el dialer/SMS por
 * defecto varía según el fabricante.
 */
object SafeApps {

    private val EMERGENCY_FIXED = setOf(
        "com.whatsapp",
        "com.whatsapp.w4b"
    )

    private val SYSTEM_SAFE_FIXED = setOf(
        "com.android.settings"
    )

    fun emergencyPackages(context: Context): Set<String> {
        val result = mutableSetOf<String>()
        result.addAll(EMERGENCY_FIXED)
        defaultDialerPackage(context)?.let { result.add(it) }
        defaultSmsPackage(context)?.let { result.add(it) }
        return result
    }

    fun alwaysSafePackages(context: Context): Set<String> {
        val result = mutableSetOf<String>()
        result.addAll(SYSTEM_SAFE_FIXED)
        result.add(context.packageName)
        defaultLauncherPackage(context)?.let { result.add(it) }
        result.addAll(emergencyPackages(context))
        return result
    }

    fun defaultDialerPackage(context: Context): String? = try {
        val tm = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
        tm?.defaultDialerPackage
    } catch (e: Exception) {
        null
    }

    fun defaultSmsPackage(context: Context): String? = try {
        Telephony.Sms.getDefaultSmsPackage(context)
    } catch (e: Exception) {
        null
    }

    fun defaultLauncherPackage(context: Context): String? = try {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName
    } catch (e: Exception) {
        null
    }
}
