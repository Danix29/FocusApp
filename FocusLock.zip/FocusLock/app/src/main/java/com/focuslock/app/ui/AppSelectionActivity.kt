package com.focuslock.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.CheckBox
import androidx.appcompat.app.AppCompatActivity
import com.focuslock.app.data.Prefs
import com.focuslock.app.databinding.ActivityAppSelectionBinding
import com.focuslock.app.service.SafeApps

class AppSelectionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAppSelectionBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppSelectionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnDone.setOnClickListener { finish() }

        val pm = packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val safePackages = SafeApps.alwaysSafePackages(this)

        val apps = pm.queryIntentActivities(launcherIntent, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .filter { it.first !in safePackages }
            .sortedBy { it.second.lowercase() }

        val blocked = Prefs.blockedApps.toMutableSet()

        for ((packageName, label) in apps) {
            val checkBox = CheckBox(this)
            checkBox.text = label
            checkBox.isChecked = blocked.contains(packageName)
            checkBox.setPadding(0, 16, 0, 16)
            checkBox.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) blocked.add(packageName) else blocked.remove(packageName)
                Prefs.blockedApps = blocked.toSet()
            }
            binding.containerApps.addView(checkBox)
        }
    }
}
