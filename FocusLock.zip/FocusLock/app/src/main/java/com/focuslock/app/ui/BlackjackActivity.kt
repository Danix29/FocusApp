package com.focuslock.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.focuslock.app.databinding.ActivityBlackjackBinding
import com.focuslock.app.games.BlackjackGame
import com.focuslock.app.restrict.RestrictionManager

class BlackjackActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBlackjackBinding
    private val game = BlackjackGame()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBlackjackBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnHit.setOnClickListener { game.hit(); render() }
        binding.btnStand.setOnClickListener { game.stand(); render() }
        binding.btnContinue.setOnClickListener {
            if (game.playerWon) {
                RestrictionManager.recordWin("blackjack")
            } else {
                RestrictionManager.recordLoss("blackjack")
            }
            finish()
        }

        render()
    }

    private fun render() {
        binding.tvDealerHand.text = game.dealerHand.joinToString(" ") { it.display() }
        binding.tvPlayerHand.text = game.playerHand.joinToString(" ") { it.display() }
        binding.tvDealerTotal.text = "Total: ${game.handValue(game.dealerHand)}"
        binding.tvPlayerTotal.text = "Total: ${game.handValue(game.playerHand)}"

        if (game.finished) {
            binding.tvResult.text = game.resultText
            binding.tvResult.visibility = android.view.View.VISIBLE
            binding.btnHit.isEnabled = false
            binding.btnStand.isEnabled = false
            binding.btnContinue.visibility = android.view.View.VISIBLE
        }
    }
}
