package com.focuslock.app.ui

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.focuslock.app.databinding.ActivityBlockOverlayBinding
import com.focuslock.app.restrict.RestrictionManager

class BlockOverlayActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_BLOCKED_PACKAGE = "extra_blocked_package"
    }

    private lateinit var binding: ActivityBlockOverlayBinding
    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            render()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBlockOverlayBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val blockedPackage = intent.getStringExtra(EXTRA_BLOCKED_PACKAGE)
        binding.tvBlockedApp.text = "Has abierto: ${appLabel(blockedPackage)}"

        binding.btnBlackjack.setOnClickListener {
            startActivity(Intent(this, BlackjackActivity::class.java))
        }
        binding.btnCoinFlip.setOnClickListener {
            startActivity(
                Intent(this, SimpleGameActivity::class.java)
                    .putExtra(SimpleGameActivity.EXTRA_GAME_ID, "coin_flip")
            )
        }
        binding.btnDice.setOnClickListener {
            startActivity(
                Intent(this, SimpleGameActivity::class.java)
                    .putExtra(SimpleGameActivity.EXTRA_GAME_ID, "dice")
            )
        }
        binding.btnEmergency.setOnClickListener {
            startActivity(Intent(this, EmergencyActivity::class.java))
        }
        binding.btnGoHome.setOnClickListener { goHome() }
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        goHome()
    }

    private fun goHome() {
        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        homeIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(homeIntent)
        finish()
    }

    private fun render() {
        if (RestrictionManager.isFree()) {
            finish()
            return
        }

        binding.tvPenaltyInfo.text = "Penalización actual: ${RestrictionManager.currentPenaltyMinutes()} min"

        val canPlay = RestrictionManager.canPlayNow()
        binding.btnBlackjack.isEnabled = canPlay
        binding.btnCoinFlip.isEnabled = canPlay
        binding.btnDice.isEnabled = canPlay

        if (canPlay) {
            binding.tvCooldownInfo.visibility = android.view.View.GONE
        } else {
            binding.tvCooldownInfo.visibility = android.view.View.VISIBLE
            val remainingSec = RestrictionManager.retryMillisRemaining() / 1000
            binding.tvCooldownInfo.text =
                "Podrás reintentar en %d:%02d".format(remainingSec / 60, remainingSec % 60)
        }
    }

    private fun appLabel(packageName: String?): String {
        if (packageName == null) return "una app bloqueada"
        return try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(packageName, 0)).toString()
        } catch (e: PackageManager.NameNotFoundException) {
            packageName
        }
    }
}
