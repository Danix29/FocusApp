package com.focuslock.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.focuslock.app.databinding.ActivityEmergencyBinding

class EmergencyActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEmergencyBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEmergencyBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnPhone.setOnClickListener {
            safeStart(Intent(Intent.ACTION_DIAL))
        }
        binding.btnSms.setOnClickListener {
            safeStart(Intent(Intent.ACTION_VIEW, Uri.parse("sms:")))
        }
        binding.btnWhatsapp.setOnClickListener { openWhatsapp() }
        binding.btnClose.setOnClickListener { finish() }
    }

    private fun openWhatsapp() {
        val pm = packageManager
        val launchIntent = pm.getLaunchIntentForPackage("com.whatsapp")
            ?: pm.getLaunchIntentForPackage("com.whatsapp.w4b")
        if (launchIntent != null) {
            startActivity(launchIntent)
        } else {
            safeStart(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.whatsapp")))
        }
    }

    private fun safeStart(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "No se encontró una app para esta acción.", Toast.LENGTH_SHORT).show()
        }
    }
}
