package com.focuslock.app.ui

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.focuslock.app.FocusLockApp
import com.focuslock.app.databinding.ActivityHistoryBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHistoryBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val historyDb = (application as FocusLockApp).historyDb
        val (wins, losses) = historyDb.winLossCount()
        binding.tvStats.text = "Victorias: $wins   ·   Derrotas: $losses"

        val format = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
        val sessions = historyDb.recentGameSessions()

        if (sessions.isEmpty()) {
            val empty = TextView(this)
            empty.text = "Todavía no hay partidas registradas."
            empty.setTextColor(getColor(com.focuslock.app.R.color.textSecondary))
            binding.containerHistory.addView(empty)
        }

        for (session in sessions) {
            val line = TextView(this)
            val icon = if (session.won) "✅" else "❌"
            val dateText = format.format(Date(session.timestamp))
            line.text =
                "$icon ${session.gameType} — $dateText — ${session.penaltyBeforeMin}→${session.penaltyAfterMin} min"
            line.setTextColor(getColor(com.focuslock.app.R.color.textPrimary))
            line.setPadding(0, 8, 0, 8)
            binding.containerHistory.addView(line)
        }
    }
}
