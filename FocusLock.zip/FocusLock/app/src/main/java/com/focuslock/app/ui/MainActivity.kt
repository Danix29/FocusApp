package com.focuslock.app.ui

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.accessibility.AccessibilityManager
import androidx.appcompat.app.AppCompatActivity
import com.focuslock.app.databinding.ActivityMainBinding
import com.focuslock.app.restrict.RestrictionManager
import com.focuslock.app.service.AppBlockerService

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            render()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnEnableAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        binding.btnSelectApps.setOnClickListener {
            startActivity(Intent(this, AppSelectionActivity::class.java))
        }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        binding.btnEmergency.setOnClickListener {
            startActivity(Intent(this, EmergencyActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    private fun render() {
        binding.cardPermission.visibility = if (isAccessibilityServiceEnabled()) View.GONE else View.VISIBLE

        if (RestrictionManager.isFree()) {
            binding.tvStateValue.text = "LIBRE"
            binding.tvStateValue.setTextColor(getColor(com.focuslock.app.R.color.success))
            val remainingSec = RestrictionManager.freeMillisRemaining() / 1000
            binding.tvStateDetail.text =
                "Tiempo libre restante: %d:%02d".format(remainingSec / 60, remainingSec % 60)
        } else {
            binding.tvStateValue.text = "BLOQUEO ACTIVO"
            binding.tvStateValue.setTextColor(getColor(com.focuslock.app.R.color.danger))
            val penalty = RestrictionManager.currentPenaltyMinutes()
            binding.tvStateDetail.text = if (RestrictionManager.canPlayNow()) {
                "Penalización actual: $penalty min. Abre una app bloqueada para intentar ganar tiempo libre."
            } else {
                val remainingSec = RestrictionManager.retryMillisRemaining() / 1000
                "Penalización actual: $penalty min. Podrás reintentar en %d:%02d".format(
                    remainingSec / 60, remainingSec % 60
                )
            }
        }
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        return enabledServices.any {
            it.resolveInfo.serviceInfo.packageName == packageName &&
                it.resolveInfo.serviceInfo.name == AppBlockerService::class.java.name
        }
    }
}
