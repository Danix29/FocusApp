package com.focuslock.app.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.focuslock.app.data.Prefs
import com.focuslock.app.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.etWinProbability.setText(Prefs.winProbabilityPercent.toString())
        binding.etFreeWindow.setText(Prefs.freeWindowMinutes.toString())
        binding.etPenaltyMultiplier.setText(Prefs.penaltyMultiplierPercent.toString())
        binding.etBasePenalty.setText(Prefs.basePenaltyMinutes.toString())
        binding.etMaxPenalty.setText(Prefs.maxPenaltyMinutes.toString())
        binding.etResetHour.setText(Prefs.dailyResetHour.toString())

        binding.btnSave.setOnClickListener { save() }
    }

    private fun save() {
        val winProbability = binding.etWinProbability.text.toString().toIntOrNull()
        val freeWindow = binding.etFreeWindow.text.toString().toIntOrNull()
        val multiplier = binding.etPenaltyMultiplier.text.toString().toIntOrNull()
        val basePenalty = binding.etBasePenalty.text.toString().toIntOrNull()
        val maxPenalty = binding.etMaxPenalty.text.toString().toIntOrNull()
        val resetHour = binding.etResetHour.text.toString().toIntOrNull()

        if (winProbability == null || freeWindow == null || multiplier == null ||
            basePenalty == null || maxPenalty == null || resetHour == null
        ) {
            Toast.makeText(this, "Revisa los campos, hay valores inválidos.", Toast.LENGTH_SHORT).show()
            return
        }

        Prefs.winProbabilityPercent = winProbability.coerceIn(1, 95)
        Prefs.freeWindowMinutes = freeWindow.coerceIn(1, 240)
        Prefs.penaltyMultiplierPercent = multiplier.coerceIn(101, 500)
        Prefs.basePenaltyMinutes = basePenalty.coerceIn(1, 240)
        Prefs.maxPenaltyMinutes = maxPenalty.coerceAtLeast(Prefs.basePenaltyMinutes).coerceIn(1, 1440)
        Prefs.dailyResetHour = resetHour.coerceIn(0, 23)

        Toast.makeText(this, "Ajustes guardados.", Toast.LENGTH_SHORT).show()
        finish()
    }
}
