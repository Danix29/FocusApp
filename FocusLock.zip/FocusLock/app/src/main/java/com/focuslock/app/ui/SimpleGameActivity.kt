package com.focuslock.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.focuslock.app.databinding.ActivitySimpleGameBinding
import com.focuslock.app.games.CoinFlipGame
import com.focuslock.app.games.DiceGame
import com.focuslock.app.games.GameResult
import com.focuslock.app.games.QuickGame
import com.focuslock.app.restrict.RestrictionManager

class SimpleGameActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_GAME_ID = "extra_game_id"
    }

    private lateinit var binding: ActivitySimpleGameBinding
    private lateinit var game: QuickGame
    private var lastResult: GameResult? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySimpleGameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        game = if (intent.getStringExtra(EXTRA_GAME_ID) == DiceGame.id) DiceGame else CoinFlipGame

        binding.tvGameTitle.text = game.displayName
        binding.tvGameDescription.text =
            "Si ganas, sumas tiempo libre. Si pierdes, tu penalización se multiplica."

        binding.btnPlay.setOnClickListener {
            val result = game.play(RestrictionManager.winProbability())
            lastResult = result
            binding.tvResult.text = if (result.won) {
                "${result.detail}\n¡Ganaste!"
            } else {
                "${result.detail}\nPerdiste."
            }
            binding.tvResult.visibility = android.view.View.VISIBLE
            binding.btnPlay.visibility = android.view.View.GONE
            binding.btnContinue.visibility = android.view.View.VISIBLE
        }

        binding.btnContinue.setOnClickListener {
            val result = lastResult
            if (result != null) {
                if (result.won) RestrictionManager.recordWin(game.id) else RestrictionManager.recordLoss(game.id)
            }
            finish()
        }
    }
}
